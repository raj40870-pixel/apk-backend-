let currentInput = '0';
let previousInput = '';
let operation = null;
let resetScreen = false;

const display = document.getElementById('display');
const historyDisplay = document.getElementById('history');
const timeDisplay = document.getElementById('status-time');

// Update Clock
function updateClock() {
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  timeDisplay.textContent = `${hours}:${minutes}`;
}
setInterval(updateClock, 1000);
updateClock();

// Web Audio API Click Feedback
let audioCtx = null;
function playClickSound() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(600, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(150, audioCtx.currentTime + 0.04);
    gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.04);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.04);
  } catch (_) {}
}

function updateDisplay() {
  display.textContent = currentInput;
  if (currentInput.length > 9) {
    display.style.fontSize = '32px';
  } else if (currentInput.length > 6) {
    display.style.fontSize = '38px';
  } else {
    display.style.fontSize = '48px';
  }
}

function appendNumber(num) {
  playClickSound();
  if (currentInput === '0' || resetScreen) {
    currentInput = num === '.' ? '0.' : num;
    resetScreen = false;
  } else {
    if (num === '.' && currentInput.includes('.')) return;
    currentInput += num;
  }
  updateDisplay();
}

function chooseOperation(op) {
  playClickSound();
  if (currentInput === '') return;
  if (previousInput !== '') {
    calculate();
  }
  operation = op;
  previousInput = currentInput;
  historyDisplay.textContent = `${previousInput} ${operation}`;
  resetScreen = true;
}

function calculate() {
  playClickSound();
  let computation;
  const prev = parseFloat(previousInput);
  const current = parseFloat(currentInput);
  if (isNaN(prev) || isNaN(current)) return;

  switch (operation) {
    case '+':
      computation = prev + current;
      break;
    case '-':
      computation = prev - current;
      break;
    case '×':
      computation = prev * current;
      break;
    case '÷':
      if (current === 0) {
        currentInput = 'Error';
        updateDisplay();
        return;
      }
      computation = prev / current;
      break;
    default:
      return;
  }

  // Round to prevent floating point inaccuracies
  computation = Math.round(computation * 100000000) / 100000000;
  historyDisplay.textContent = `${previousInput} ${operation} ${currentInput} =`;
  currentInput = computation.toString();
  operation = null;
  previousInput = '';
  resetScreen = true;
  updateDisplay();
}

function clearAll() {
  playClickSound();
  currentInput = '0';
  previousInput = '';
  operation = null;
  historyDisplay.textContent = '';
  updateDisplay();
}

function backspace() {
  playClickSound();
  if (currentInput.length === 1 || currentInput === 'Error') {
    currentInput = '0';
  } else {
    currentInput = currentInput.slice(0, -1);
  }
  updateDisplay();
}

function percentage() {
  playClickSound();
  currentInput = (parseFloat(currentInput) / 100).toString();
  updateDisplay();
}

// Button Click Listeners
document.querySelectorAll('[data-num]').forEach(btn => {
  btn.addEventListener('click', () => appendNumber(btn.dataset.num));
});

document.querySelectorAll('[data-op]').forEach(btn => {
  btn.addEventListener('click', () => chooseOperation(btn.dataset.op));
});

document.querySelectorAll('[data-action]').forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.action;
    if (action === 'clear') clearAll();
    if (action === 'backspace') backspace();
    if (action === 'percent') percentage();
    if (action === 'calculate') calculate();
  });
});

// Keyboard Support
window.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') appendNumber(e.key);
  if (e.key === '.') appendNumber('.');
  if (e.key === '=' || e.key === 'Enter') calculate();
  if (e.key === 'Backspace') backspace();
  if (e.key === 'Escape') clearAll();
  if (e.key === '+') chooseOperation('+');
  if (e.key === '-') chooseOperation('-');
  if (e.key === '*') chooseOperation('×');
  if (e.key === '/') chooseOperation('÷');
  if (e.key === '%') percentage();
});
